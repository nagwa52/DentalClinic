This project uses several languages such as :
  Front-end: html,css
  backend: php
  database used: mysql

This project requires server, please make sure to import dentalclinic.sql in your mysql database before openning index.html file in dental folder.
